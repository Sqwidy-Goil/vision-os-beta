// Service worker registration (PWA / offline shell)
export function registerSW() {
  if (!('serviceWorker' in navigator)) return;
  if (location.protocol === 'file:') return; // local preview
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('service-worker.js', { scope: '.' })
      .catch((e) => console.warn('SW registration failed:', e));
  });
}
