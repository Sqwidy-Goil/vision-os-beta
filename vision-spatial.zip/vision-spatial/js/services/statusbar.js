import { state, on } from '../core/state.js';

export function initStatusbar() {
  const clock = document.getElementById('sb-clock');
  const tick = () => {
    const d = new Date();
    clock.textContent = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  tick(); setInterval(tick, 15000);

  const render = () => {
    document.getElementById('sb-track').classList.toggle('on', state.orientation.enabled);
    document.getElementById('sb-cam').classList.toggle('on', state.camera.active);
    document.getElementById('sb-net').classList.toggle('on', state.net);
  };
  on('state', render);
  window.addEventListener('online', () => { state.net = true; render(); });
  window.addEventListener('offline', () => { state.net = false; render(); });
  render();
}
