// VISI0N SPATIAL — bootstrap
import { initEnvironment } from './spatial/environment.js';
import { initDock } from './spatial/dock.js';
import { initOrientation } from './orientation/orientation.js';
import { initStatusbar } from './services/statusbar.js';
import { registerSW } from './services/sw.js';
import { state } from './core/state.js';
import { APPS } from './apps/index.js';

// Gentle parallax from orientation (view yaw/pitch -> background + windows drift)
function applyView(v) {
  const drift = document.getElementById('windows');
  drift.style.transform = `translate3d(${-v.yaw * 1.2}px, ${-v.pitch * 0.8}px, 0)`;
  document.getElementById('env-bg').style.transform =
    `translate3d(${v.yaw * 2.2}px, ${v.pitch * 1.4}px, 0) scale(1.04)`;
}

initEnvironment();
initStatusbar();
initOrientation(applyView);
initDock(APPS);
registerSW();

document.getElementById('btn-settings').addEventListener('click', () => {
  const s = APPS.find((a) => a.id === 'settings');
  import('./spatial/windowManager.js').then(({ openWindow }) => openWindow(s));
});

// Prevent page scroll/zoom gestures inside the spatial stage
document.getElementById('space').addEventListener('touchmove', (e) => e.preventDefault(), { passive: false });

// Set initial body datasets from state
document.body.dataset.env = state.env;
document.body.dataset.quality = state.quality;
