import { state, setState, on } from '../core/state.js';

const ENVIRONMENTS = ['dark', 'futuristic', 'light', 'workspace'];

export function initEnvironment() {
  // Buttons in the picker modal
  const picker = document.getElementById('env-picker');
  document.getElementById('btn-environments').addEventListener('click', () => {
    picker.hidden = !picker.hidden;
    picker.querySelectorAll('button').forEach((b) =>
      b.classList.toggle('sel', b.dataset.env === state.env));
  });
  picker.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-env]');
    if (!btn) return;
    setEnvironment(btn.dataset.env);
    picker.hidden = true;
  });
  // Sync body dataset
  on('state', () => { document.body.dataset.env = state.env; document.body.dataset.quality = state.quality; });
}

export function setEnvironment(env) {
  if (!ENVIRONMENTS.includes(env)) return;
  setState({ env });
}

export function cycleEnvironment() {
  const i = ENVIRONMENTS.indexOf(state.env);
  setEnvironment(ENVIRONMENTS[(i + 1) % ENVIRONMENTS.length]);
}
