// Spatial window manager: open/close/minimize/move/focus/resize
import { state, setState, emit, on } from '../core/state.js';
import { toast } from '../core/errors.js';

let zTop = 10;
let seq = 0;
const LAYER = () => document.getElementById('windows');

export function openWindow(app) {
  // Focus existing instance (single-instance apps)
  const existing = [...state.windows.values()].find((w) => w.appId === app.id);
  if (existing) { restoreWindow(existing.id); focusWindow(existing.id); return existing.id; }

  const id = 'win-' + (++seq);
  const el = document.createElement('section');
  el.className = 'glass-window';
  el.dataset.win = id;
  el.setAttribute('role', 'dialog');
  el.setAttribute('aria-label', app.name);

  const vw = window.innerWidth, vh = window.innerHeight;
  const w = Math.min(app.width || 340, vw - 24);
  const h = Math.min(app.height || 420, vh * 0.62);
  const x = Math.max(12, (vw - w) / 2 + (seq % 5 - 2) * 18);
  const y = Math.max(56, (vh - h) / 2.4 + (seq % 4) * 16);

  el.style.width = w + 'px'; el.style.height = h + 'px';
  el.style.transform = `translate3d(${x}px, ${y}px, 0)`;

  el.innerHTML = `
    <header class="win-titlebar">
      <span class="win-title">${app.name}</span>
      <button class="win-btn min" title="Minimize">–</button>
      <button class="win-btn close" title="Close">✕</button>
    </header>
    <div class="win-body"></div>
    <div class="win-resize" title="Resize"></div>`;

  LAYER().appendChild(el);

  const rec = { id, appId: app.id, el, minimized: false, x, y, w, h };
  state.windows.set(id, rec);
  setState({}); emit('windows');
  focusWindow(id);
  attachDrag(rec); attachResize(rec); attachChrome(rec);

  // Mount app content
  const body = el.querySelector('.win-body');
  try { app.mount(body, rec); }
  catch (e) { toast(`Failed to start ${app.name}: ${e.message}`, 'error'); closeWindow(id); return null; }

  // Entrance animation
  el.animate(
    [{ opacity: 0, transform: el.style.transform + ' scale(.85)' },
     { opacity: 1, transform: el.style.transform + ' scale(1)' }],
    { duration: 260, easing: 'cubic-bezier(.2,.9,.3,1.2)' });
  return id;
}

function attachChrome(rec) {
  rec.el.querySelector('.close').addEventListener('click', () => closeWindow(rec.id));
  rec.el.querySelector('.min').addEventListener('click', () => minimizeWindow(rec.id));
  rec.el.addEventListener('pointerdown', () => focusWindow(rec.id), true);
}

export function closeWindow(id) {
  const rec = state.windows.get(id);
  if (!rec) return;
  rec.el.animate([{ opacity: 1 }, { opacity: 0, transform: rec.el.style.transform + ' scale(.9)' }], { duration: 180, fill: 'forwards' })
    .onfinish = () => { rec.el.remove(); state.windows.delete(id); emit('windows'); emit('closed', rec); };
}

export function minimizeWindow(id) {
  const rec = state.windows.get(id);
  if (!rec) return;
  rec.minimized = true;
  rec.el.style.display = 'none';
  emit('windows');
}

export function restoreWindow(id) {
  const rec = state.windows.get(id);
  if (!rec) return;
  rec.minimized = false;
  rec.el.style.display = 'flex';
  emit('windows');
}

export function focusWindow(id) {
  const rec = state.windows.get(id);
  if (!rec) return;
  state.windows.forEach((r) => r.el.classList.remove('focused'));
  rec.el.classList.add('focused');
  rec.el.style.zIndex = ++zTop;
  setState({ focused: id });
  emit('windows');
}

function attachDrag(rec) {
  const bar = rec.el.querySelector('.win-titlebar');
  bar.addEventListener('pointerdown', (e) => {
    if (e.target.closest('.win-btn')) return;
    bar.setPointerCapture(e.pointerId);
    const sx = e.clientX - rec.x, sy = e.clientY - rec.y;
    const move = (ev) => {
      rec.x = clamp(ev.clientX - sx, -rec.w * 0.4, window.innerWidth - rec.w * 0.3);
      rec.y = clamp(ev.clientY - sy, 40, window.innerHeight - 80);
      rec.el.style.transform = `translate3d(${rec.x}px, ${rec.y}px, 0)`;
    };
    const up = () => { bar.removeEventListener('pointermove', move); bar.removeEventListener('pointerup', up); bar.removeEventListener('pointercancel', up); };
    bar.addEventListener('pointermove', move);
    bar.addEventListener('pointerup', up);
    bar.addEventListener('pointercancel', up);
  });
}

function attachResize(rec) {
  const handle = rec.el.querySelector('.win-resize');
  handle.addEventListener('pointerdown', (e) => {
    handle.setPointerCapture(e.pointerId);
    e.preventDefault();
    const sx = e.clientX, sy = e.clientY, sw = rec.w, sh = rec.h;
    const move = (ev) => {
      rec.w = clamp(sw + (ev.clientX - sx), 220, window.innerWidth - rec.x - 8);
      rec.h = clamp(sh + (ev.clientY - sy), 160, window.innerHeight - rec.y - 8);
      rec.el.style.width = rec.w + 'px'; rec.el.style.height = rec.h + 'px';
    };
    const up = () => { handle.removeEventListener('pointermove', move); handle.removeEventListener('pointerup', up); handle.removeEventListener('pointercancel', up); };
    handle.addEventListener('pointermove', move);
    handle.addEventListener('pointerup', up);
    handle.addEventListener('pointercancel', up);
  });
}

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

// Keep windows inside viewport on rotate
window.addEventListener('resize', () => {
  state.windows.forEach((rec) => {
    rec.x = clamp(rec.x, -rec.w * 0.4, window.innerWidth - rec.w * 0.3);
    rec.y = clamp(rec.y, 40, window.innerHeight - 80);
    rec.el.style.transform = `translate3d(${rec.x}px, ${rec.y}px, 0)`;
  });
});
