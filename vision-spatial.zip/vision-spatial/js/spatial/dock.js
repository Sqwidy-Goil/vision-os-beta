// Liquid Glass application dock
import { state, on } from '../core/state.js';
import { openWindow, restoreWindow, minimizeWindow } from './windowManager.js';

export function initDock(apps) {
  const dock = document.getElementById('dock');
  dock.innerHTML = '';
  apps.forEach((app) => {
    const b = document.createElement('button');
    b.className = 'dock-item';
    b.title = app.name;
    b.dataset.app = app.id;
    b.innerHTML = `${app.icon}<span class="dot"></span>`;
    b.addEventListener('click', () => {
      const running = [...state.windows.values()].find((w) => w.appId === app.id);
      if (!running) openWindow(app);
      else if (running.minimized) { restoreWindow(running.id); }
      else if (state.focused === running.id) minimizeWindow(running.id);
      else openWindow(app); // focuses existing
    });
    dock.appendChild(b);
  });

  on('windows', () => {
    dock.querySelectorAll('.dock-item').forEach((b) => {
      const running = [...state.windows.values()].some((w) => w.appId === b.dataset.app && !w.minimized);
      b.classList.toggle('running', running);
      b.classList.toggle('active', running);
    });
  });
}
