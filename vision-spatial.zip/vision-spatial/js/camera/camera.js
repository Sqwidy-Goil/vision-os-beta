// Real camera system: rear-facing preference, permission handling, lifecycle
import { state, setState } from '../core/state.js';
import { toast, unsupported } from '../core/errors.js';

let stream = null;

export async function startCamera(videoEl) {
  if (!navigator.mediaDevices?.getUserMedia) {
    unsupported('Camera', 'getUserMedia requires HTTPS and a compatible browser.');
    setState({ camera: { active: false, error: 'unsupported' } });
    return null;
  }
  if (stream) return stream;
  try {
    // Rear camera first, fall back to any camera
    const constraints = [
      { video: { facingMode: { ideal: 'environment' } }, audio: false },
      { video: true, audio: false },
    ];
    for (const c of constraints) {
      try {
        stream = await navigator.mediaDevices.getUserMedia(c);
        break;
      } catch (e) { /* try next */ }
    }
    if (!stream) throw new Error('Camera permission denied or no camera available.');
    if (videoEl) {
      videoEl.srcObject = stream;
      videoEl.playsInline = true;
      videoEl.muted = true;
      await videoEl.play().catch(() => {});
    }
    setState({ camera: { active: true, error: null } });
    return stream;
  } catch (e) {
    setState({ camera: { active: false, error: e.message } });
    toast(`Camera: ${e.message}`, 'error', 6000);
    return null;
  }
}

export function stopCamera() {
  if (stream) {
    stream.getTracks().forEach((t) => t.stop());
    stream = null;
  }
  setState({ camera: { active: false, error: null } });
}

// Best-effort rear camera label detection (for settings info)
export async function listCameras() {
  if (!navigator.mediaDevices?.enumerateDevices) return [];
  const devices = await navigator.mediaDevices.enumerateDevices();
  return devices.filter((d) => d.kind === 'videoinput');
}
