// Hand tracking via MediaPipe Hands (lazy-loaded) with pinch-to-tap mapping.
// Honest scope: 3-DoF orientation device + 2D hand cursor; NOT full 6-DoF spatial tracking.
import { state, setState } from '../core/state.js';
import { toast } from '../core/errors.js';

let hands = null, cameraUtils = null, active = false, videoEl = null;
let pinchCooldown = 0;

export async function enableHands() {
  if (active) return true;
  try {
    toast('Loading hand tracking model…');
    const [handsMod, camMod] = await Promise.all([
      import('https://cdn.jsdelivr.net/npm/@mediapipe/hands@0.4.1675469240/hands.js'),
      import('https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils@0.3.1675466862/camera_utils.js'),
    ]);
    cameraUtils = camMod.Camera;
    hands = new handsMod.Hands({
      locateFile: (f) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands@0.4.1675469240/${f}`,
    });
    hands.setOptions({ maxNumHands: 1, modelComplexity: 0, minDetectionConfidence: 0.6, minTrackingConfidence: 0.5 });
    hands.onResults(onResults);

    // Hidden video feed for the tracker (separate lightweight stream)
    videoEl = document.createElement('video');
    videoEl.playsInline = true; videoEl.muted = true;
    const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false });
    videoEl.srcObject = stream;
    await videoEl.play();

    const mpCam = new cameraUtils(videoEl, {
      onFrame: async () => { if (active) await hands.send({ image: videoEl }); },
      width: 320, height: 240,
    });
    await mpCam.start();
    active = true;
    setState({ hands: { enabled: true, loaded: true } });
    document.getElementById('hand-cursor').hidden = false;
    toast('Hand tracking on — pinch to tap.');
    return true;
  } catch (e) {
    toast(`Hand tracking unavailable: ${e.message}`, 'error', 6000);
    disableHands();
    return false;
  }
}

function onResults(results) {
  const cursor = document.getElementById('hand-cursor');
  const lms = results.multiHandLandmarks?.[0];
  if (!lms) { cursor.style.opacity = '0.3'; return; }
  cursor.style.opacity = '1';
  // Index fingertip (8) position -> screen space (mirror X for front camera)
  const tip = lms[8], thumb = lms[4];
  const x = (1 - tip.x) * window.innerWidth;
  const y = tip.y * window.innerHeight;
  cursor.style.left = x + 'px'; cursor.style.top = y + 'px';

  // Pinch: thumb tip close to index tip
  const dx = tip.x - thumb.x, dy = tip.y - thumb.y;
  const pinched = Math.hypot(dx, dy) < 0.05;
  cursor.classList.toggle('pinch', pinched);
  const now = performance.now();
  if (pinched && now - pinchCooldown > 350) {
    pinchCooldown = now;
    const el = document.elementFromPoint(x, y);
    el?.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, clientX: x, clientY: y }));
    el?.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, clientX: x, clientY: y }));
    el?.click?.();
  }
}

export function disableHands() {
  active = false;
  if (videoEl?.srcObject) videoEl.srcObject.getTracks().forEach((t) => t.stop());
  videoEl = null; hands = null;
  setState({ hands: { enabled: false, loaded: false } });
  const c = document.getElementById('hand-cursor');
  c.hidden = true;
}
