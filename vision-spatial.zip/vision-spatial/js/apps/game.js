import { toast } from '../core/errors.js';

const icon = `<svg viewBox="0 0 24 24"><path d="M6 9h4M8 7v4M15 8h.01M17.5 10.5h.01"/><path d="M7 5h10a5 5 0 0 1 5 5v3a4 4 0 0 1-7 2.6L13 14h-2l-2 1.6A4 4 0 0 1 2 13v-3a5 5 0 0 1 5-5z"/></svg>`;

export const gameApp = {
  id: 'game', name: 'Nebula Dodge', icon, width: 340, height: 460,
  mount(body) {
    body.innerHTML = `
      <div class="app">
        <canvas style="width:100%;flex:1;border-radius:12px;background:rgba(0,0,0,.35);touch-action:none"></canvas>
        <div class="row" style="justify-content:space-between">
          <span class="hint score">Score: 0 · Best: 0</span>
          <button class="act start">Start</button>
        </div>
        <div class="hint">Drag anywhere on the canvas to steer your ship. Survive the asteroid field.</div>
      </div>`;
    const cv = body.querySelector('canvas');
    const ctx = cv.getContext('2d');
    const scoreEl = body.querySelector('.score');
    const startBtn = body.querySelector('.start');
    let raf = null, running = false, score = 0, best = +(localStorage.getItem('vision-best') || 0);
    let ship, rocks, stars, targetX = null, lastT = 0;
    const DPR = Math.min(window.devicePixelRatio || 1, 2);

    function resize() {
      const r = cv.getBoundingClientRect();
      cv.width = r.width * DPR; cv.height = r.height * DPR;
    }
    resize(); new ResizeObserver(resize).observe(cv);

    function reset() {
      ship = { x: cv.width / 2, y: cv.height * 0.82, r: 10 * DPR };
      rocks = []; stars = Array.from({ length: 40 }, () => ({
        x: Math.random() * cv.width, y: Math.random() * cv.height, s: Math.random() * 2 + 0.4 }));
      score = 0; lastT = performance.now();
      scoreEl.textContent = `Score: 0 · Best: ${best}`;
    }
    reset();

    function loop(now) {
      if (!running) return;
      const dt = Math.min((now - lastT) / 1000, 0.05); lastT = now;
      score += dt * 10;
      // ship steers toward finger
      if (targetX !== null) ship.x += (targetX * DPR - ship.x) * Math.min(1, dt * 10);
      ship.x = Math.max(ship.r, Math.min(cv.width - ship.r, ship.x));
      // spawn rocks
      if (Math.random() < dt * (1.1 + score / 40)) {
        rocks.push({ x: Math.random() * cv.width, y: -20 * DPR, vy: (60 + Math.random() * 80 + score * 2) * DPR, r: (7 + Math.random() * 12) * DPR });
      }
      // update + collide
      for (const r of rocks) {
        r.y += r.vy * dt;
        if (Math.hypot(r.x - ship.x, r.y - ship.y) < r.r + ship.r * 0.8) return end();
      }
      rocks = rocks.filter((r) => r.y < cv.height + 40);

      // draw
      ctx.clearRect(0, 0, cv.width, cv.height);
      ctx.fillStyle = 'rgba(255,255,255,.5)';
      for (const st of stars) { st.y += 20 * DPR * dt; if (st.y > cv.height) { st.y = 0; st.x = Math.random() * cv.width; } ctx.fillRect(st.x, st.y, st.s, st.s); }
      for (const r of rocks) {
        ctx.beginPath(); ctx.arc(r.x, r.y, r.r, 0, 7);
        ctx.fillStyle = 'rgba(150,160,190,.85)'; ctx.fill();
      }
      ctx.save(); ctx.translate(ship.x, ship.y);
      ctx.beginPath(); ctx.moveTo(0, -ship.r * 1.3); ctx.lineTo(ship.r, ship.r); ctx.lineTo(0, ship.r * 0.5); ctx.lineTo(-ship.r, ship.r); ctx.closePath();
      ctx.fillStyle = '#6ee7ff'; ctx.shadowColor = '#6ee7ff'; ctx.shadowBlur = 14; ctx.fill(); ctx.restore();

      scoreEl.textContent = `Score: ${Math.floor(score)} · Best: ${best}`;
      raf = requestAnimationFrame(loop);
    }

    function end() {
      running = false; cancelAnimationFrame(raf);
      best = Math.max(best, Math.floor(score));
      localStorage.setItem('vision-best', best);
      startBtn.textContent = 'Restart';
      scoreEl.textContent = `Score: ${Math.floor(score)} · Best: ${best}`;
      toast(`Game over — score ${Math.floor(score)}!`);
      ctx.fillStyle = 'rgba(0,0,0,.55)'; ctx.fillRect(0, 0, cv.width, cv.height);
      ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.font = `${18 * DPR}px sans-serif`;
      ctx.fillText('GAME OVER', cv.width / 2, cv.height / 2);
    }

    function pointer(e) {
      const r = cv.getBoundingClientRect();
      targetX = (e.clientX - r.left) / r.width;
    }
    cv.addEventListener('pointerdown', pointer);
    cv.addEventListener('pointermove', (e) => { if (e.buttons || e.pointerType === 'touch') pointer(e); });

    startBtn.addEventListener('click', () => {
      reset(); running = true; startBtn.textContent = 'Playing…';
      cancelAnimationFrame(raf); raf = requestAnimationFrame(loop);
    });

    // stop cleanly when window closes
    const mo = new MutationObserver(() => {
      if (!document.contains(cv)) { running = false; cancelAnimationFrame(raf); mo.disconnect(); }
    });
    mo.observe(document.body, { childList: true, subtree: true });
  },
};
