import { state, setState } from '../core/state.js';
import { startCamera, stopCamera, listCameras } from '../camera/camera.js';
import { requestOrientationPermission, recenter } from '../orientation/orientation.js';
import { enableHands, disableHands } from '../tracking/hands.js';
import { toast } from '../core/errors.js';

const icon = `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1 1.55V21a2 2 0 1 1-4 0v-.09a1.7 1.7 0 0 0-1-1.55 1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-1.55-1H3a2 2 0 1 1 0-4h.09a1.7 1.7 0 0 0 1.55-1 1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-1.55V3a2 2 0 1 1 4 0v.09a1.7 1.7 0 0 0 1 1.55 1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.7 1.7 0 0 0-.34 1.87 1.7 1.7 0 0 0 1.55 1H21a2 2 0 1 1 0 4h-.09a1.7 1.7 0 0 0-1.55 1z"/></svg>`;

function toggle(label, value, onchange) {
  const row = document.createElement('label');
  row.style.cssText = 'display:flex;justify-content:space-between;align-items:center;gap:10px;padding:9px 2px;font-size:13px';
  const span = document.createElement('span'); span.textContent = label;
  const input = document.createElement('input');
  input.type = 'checkbox'; input.checked = !!value;
  input.style.cssText = 'width:20px;height:20px;flex:0 0 auto';
  input.addEventListener('change', () => onchange(input.checked));
  row.append(span, input);
  return row;
}

export const settingsApp = {
  id: 'settings', name: 'Settings', icon, width: 340, height: 480,
  mount(body) {
    body.innerHTML = `<div class="app"><h2>Settings</h2><div class="sections" style="overflow:auto;display:flex;flex-direction:column;gap:4px"></div></div>`;
    const s = body.querySelector('.sections');

    s.appendChild(Object.assign(document.createElement('div'), { className: 'hint', textContent: 'Camera' }));
    s.appendChild(toggle('Enable camera (rear)', state.camera.active, async (on) => {
      if (on) {
        const v = document.createElement('video');
        const stream = await startCamera(v);
        if (stream) toast('Camera started (preview available in Browser/AR apps).');
      } else { stopCamera(); toast('Camera stopped.'); }
    }));
    const camInfo = document.createElement('div'); camInfo.className = 'hint';
    listCameras().then((cams) => camInfo.textContent = `${cams.length} camera device(s) detected.`).catch(() => {});
    s.appendChild(camInfo);

    s.appendChild(Object.assign(document.createElement('div'), { className: 'hint', style: 'margin-top:8px', textContent: 'Orientation tracking (3-DoF)' }));
    s.appendChild(toggle('Enable motion tracking', state.orientation.enabled, async (on) => {
      if (on) await requestOrientationPermission();
      else setState({ orientation: { ...state.orientation, enabled: false } });
    }));
    const rec = document.createElement('button'); rec.className = 'act'; rec.textContent = '⟳ Recenter view';
    rec.addEventListener('click', recenter);
    s.appendChild(rec);
    const warn = document.createElement('div');
    warn.className = 'hint'; warn.style.fontSize = '11px';
    warn.textContent = 'Gyroscope provides rotation only — not full positional (6-DoF) tracking.';
    s.appendChild(warn);

    s.appendChild(Object.assign(document.createElement('div'), { className: 'hint', style: 'margin-top:8px', textContent: 'Hand tracking' }));
    s.appendChild(toggle('Enable hand tracking (MediaPipe)', state.hands.enabled, async (on) => {
      if (on) await enableHands(); else disableHands();
    }));

    s.appendChild(Object.assign(document.createElement('div'), { className: 'hint', style: 'margin-top:8px', textContent: 'Visual quality' }));
    const q = document.createElement('select');
    q.innerHTML = '<option value="low">Low</option><option value="balanced">Balanced</option><option value="high">High</option>';
    q.value = state.quality;
    q.addEventListener('change', () => { setState({ quality: q.value }); toast(`Quality: ${q.value}`); });
    s.appendChild(q);

    s.appendChild(Object.assign(document.createElement('div'), { className: 'hint', style: 'margin-top:8px', textContent: 'Permissions & privacy' }));
    const p = document.createElement('div'); p.className = 'hint'; p.style.fontSize = '11px';
    p.textContent = 'Camera & motion access require HTTPS and are requested only by your tap. Nothing is recorded or transmitted; streams stop when disabled.';
    s.appendChild(p);
    const perf = document.createElement('div'); perf.className = 'hint'; perf.style.fontSize = '11px';
    const mem = navigator.deviceMemory ? ` ~${navigator.deviceMemory} GB device memory.` : '';
    perf.textContent = `${navigator.hardwareConcurrency || '?'} CPU cores.${mem}`;
    s.appendChild(perf);
  },
};
