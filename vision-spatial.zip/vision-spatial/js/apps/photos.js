import { toast } from '../core/errors.js';

const icon = `<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2"/><path d="M4 18l5-5 3 3 4-4 4 4"/></svg>`;

export const photosApp = {
  id: 'photos', name: 'Photos', icon, width: 360, height: 440,
  mount(body) {
    body.innerHTML = `
      <div class="app">
        <input type="file" accept="image/*" multiple hidden>
        <button class="act pick">Import photos…</button>
        <div class="grid"></div>
        <div class="hint count">0 photos</div>
      </div>
      <div class="lightbox" hidden style="position:absolute;inset:0;z-index:10;background:rgba(0,0,0,.85);display:grid;place-items:center;border-radius:inherit">
        <img style="max-width:92%;max-height:80%;border-radius:10px;transition:transform .2s">
        <div class="row" style="position:absolute;bottom:14px;left:0;right:0;justify-content:center">
          <button class="act zout">−</button>
          <button class="act zin">+</button>
          <button class="act close-lb">✕ Close</button>
        </div>
      </div>`;
    const file = body.querySelector('input[type=file]');
    const grid = body.querySelector('.grid');
    const count = body.querySelector('.count');
    const lb = body.querySelector('.lightbox');
    const lbImg = lb.querySelector('img');
    let zoom = 1, urls = [];

    body.querySelector('.pick').addEventListener('click', () => file.click());
    file.addEventListener('change', () => {
      grid.innerHTML = '';
      urls.forEach((u) => URL.revokeObjectURL(u));
      urls = [...file.files].map((f) => URL.createObjectURL(f));
      urls.forEach((u, i) => {
        const img = document.createElement('img');
        img.src = u; img.alt = file.files[i].name;
        img.addEventListener('click', () => openLB(u));
        grid.appendChild(img);
      });
      count.textContent = `${urls.length} photo${urls.length === 1 ? '' : 's'}`;
      if (!urls.length) toast('No images selected.');
    });

    function openLB(u) { zoom = 1; lbImg.style.transform = 'scale(1)'; lbImg.src = u; lb.hidden = false; }
    lb.querySelector('.close-lb').addEventListener('click', () => lb.hidden = true);
    lb.addEventListener('click', (e) => { if (e.target === lb) lb.hidden = true; });
    lb.querySelector('.zin').addEventListener('click', () => { zoom = Math.min(4, zoom + 0.4); lbImg.style.transform = `scale(${zoom})`; });
    lb.querySelector('.zout').addEventListener('click', () => { zoom = Math.max(1, zoom - 0.4); lbImg.style.transform = `scale(${zoom})`; });
  },
};
