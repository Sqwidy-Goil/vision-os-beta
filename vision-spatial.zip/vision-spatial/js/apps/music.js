import { toast } from '../core/errors.js';

const icon = `<svg viewBox="0 0 24 24"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>`;

export const musicApp = {
  id: 'music', name: 'Music', icon, width: 340, height: 420,
  mount(body) {
    body.innerHTML = `
      <div class="app" style="text-align:center">
        <div class="field"><input type="file" accept="audio/*" hidden></div>
        <div style="width:150px;height:150px;margin:6px auto;border-radius:24px;display:grid;place-items:center;font-size:44px;
          background:linear-gradient(135deg,var(--accent),#a78bfa);box-shadow:0 14px 40px rgba(0,0,0,.4)">♪</div>
        <div class="hint track">No track loaded</div>
        <input type="range" class="seek" min="0" max="1000" value="0">
        <div class="row" style="justify-content:center">
          <button class="act pick">Load audio…</button>
          <button class="act play" disabled>▶</button>
        </div>
        <div class="row"><span class="hint">🔊</span><input type="range" class="vol" min="0" max="1" step="0.01" value="0.9"></div>
        <div class="hint" style="font-size:11px">Streaming services (Spotify/Apple Music) require their own OAuth apps &amp; API keys; they cannot be embedded here without credentials.</div>
        <audio></audio>
      </div>`;
    const file = body.querySelector('input[type=file]');
    const audio = body.querySelector('audio');
    const play = body.querySelector('.play');
    const track = body.querySelector('.track');
    const seek = body.querySelector('.seek');

    body.querySelector('.pick').addEventListener('click', () => file.click());
    file.addEventListener('change', () => {
      const f = file.files[0]; if (!f) return;
      audio.src = URL.createObjectURL(f);
      track.textContent = `${f.name} — ${(f.size / 1e6).toFixed(1)} MB`;
      play.disabled = false;
      audio.play().catch(() => {});
    });
    play.addEventListener('click', () => audio.paused ? audio.play() : audio.pause());
    audio.addEventListener('play', () => play.textContent = '⏸');
    audio.addEventListener('pause', () => play.textContent = '▶');
    audio.addEventListener('error', () => { if (audio.src) toast('Could not play this audio file.', 'error'); });
    seek.addEventListener('input', () => { if (audio.duration) audio.currentTime = seek.value / 1000 * audio.duration; });
    audio.addEventListener('timeupdate', () => { if (audio.duration) seek.value = audio.currentTime / audio.duration * 1000; });
    body.querySelector('.vol').addEventListener('input', (e) => audio.volume = +e.target.value);
  },
};
