import { browserApp } from './browser.js';
import { videoApp } from './video.js';
import { photosApp } from './photos.js';
import { viewer3dApp } from './viewer3d.js';
import { musicApp } from './music.js';
import { keyboardApp } from './keyboard.js';
import { settingsApp } from './settings.js';
import { gameApp } from './game.js';

export const APPS = [
  browserApp, videoApp, photosApp, viewer3dApp,
  musicApp, keyboardApp, settingsApp, gameApp,
];
