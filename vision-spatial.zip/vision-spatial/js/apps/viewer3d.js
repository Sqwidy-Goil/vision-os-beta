import { toast } from '../core/errors.js';

const icon = `<svg viewBox="0 0 24 24"><path d="M12 2l9 5v10l-9 5-9-5V7z"/><path d="M12 12l9-5M12 12v10M12 12L3 7"/></svg>`;

export const viewer3dApp = {
  id: 'viewer3d', name: '3D Viewer', icon, width: 380, height: 440,
  mount(body) {
    body.innerHTML = `
      <div class="app">
        <div class="row">
          <button class="act demo">Demo object</button>
          <button class="act ar" hidden>View in AR ⎋</button>
        </div>
        <div class="field">
          <input class="model-url" placeholder="https://…/model.glb (glTF/GLB URL)" inputmode="url">
          <button class="act load">Load</button>
        </div>
        <div class="stage" style="flex:1;min-height:200px;border-radius:12px;overflow:hidden;background:rgba(0,0,0,.25);position:relative">
          <div class="hint placeholder" style="position:absolute;inset:0;display:grid;place-items:center">Load a model or open the demo.<br>Drag to rotate · pinch/scroll to zoom.</div>
        </div>
        <div class="hint">AR Quick Look requires a .usdz model with an ios-src attribute.</div>
      </div>`;
    const stage = body.querySelector('.stage');
    const placeholder = body.querySelector('.placeholder');

    async function showModel(src, iosSrc) {
      placeholder.style.display = 'none';
      stage.innerHTML = '';
      // model-viewer gives us glTF loading + iOS AR Quick Look for free
      await import('https://cdn.jsdelivr.net/npm/@google/model-viewer@3/dist/model-viewer.min.js')
        .catch(() => { throw new Error('Could not load the 3D engine (offline?).'); });
      const mv = document.createElement('model-viewer');
      mv.setAttribute('src', src);
      if (iosSrc) mv.setAttribute('ios-src', iosSrc);
      mv.setAttribute('ar', ''); mv.setAttribute('ar-modes', 'quick-look');
      mv.setAttribute('camera-controls', ''); mv.setAttribute('touch-action', 'pan-y');
      mv.setAttribute('shadow-intensity', '1'); mv.setAttribute('auto-rotate', '');
      mv.style.cssText = 'width:100%;height:100%;--poster-color:transparent';
      mv.addEventListener('error', () => toast('Failed to load this model. Check the URL (CORS must allow it).', 'error', 6000));
      stage.appendChild(mv);
      const arBtn = body.querySelector('.ar');
      arBtn.hidden = !iosSrc;
      if (iosSrc) arBtn.onclick = () => mv.activateAR();
    }

    body.querySelector('.demo').addEventListener('click', () => {
      // Built-in demo via model-viewer's hosted sample (network required)
      showModel('https://modelviewer.dev/shared-assets/models/Astronaut.glb')
        .catch((e) => toast(e.message, 'error'));
    });
    body.querySelector('.load').addEventListener('click', () => {
      const url = body.querySelector('.model-url').value.trim();
      if (!url) return toast('Enter a model URL first.');
      showModel(url).catch((e) => toast(e.message, 'error'));
    });
  },
};
