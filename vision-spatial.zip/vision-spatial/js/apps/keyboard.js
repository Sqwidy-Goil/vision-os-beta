const icon = `<svg viewBox="0 0 24 24"><rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M6 14h.01M18 14h.01M9 14h6"/></svg>`;

const ROWS = [
  ['q','w','e','r','t','y','u','i','o','p'],
  ['a','s','d','f','g','h','j','k','l'],
  ['⇧','z','x','c','v','b','n','m','⌫'],
];

export const keyboardApp = {
  id: 'keyboard', name: 'Keyboard', icon, width: 380, height: 400,
  mount(body) {
    body.innerHTML = `
      <div class="app">
        <textarea rows="3" placeholder="Tap keys to type here…" style="width:100%"></textarea>
        <div class="kbd" style="flex:1;display:flex;flex-direction:column;gap:6px"></div>
        <button class="act close-kb" style="width:100%">▼ Close keyboard</button>
      </div>`;
    const ta = body.querySelector('textarea');
    const kbd = body.querySelector('.kbd');
    let shift = false;

    function render() {
      kbd.innerHTML = '';
      ROWS.forEach((row, ri) => {
        const r = document.createElement('div');
        r.style.cssText = 'display:flex;gap:5px;justify-content:center;flex:1';
        row.forEach((k) => {
          const b = document.createElement('button');
          b.className = 'key';
          const label = (k.length === 1 && shift) ? k.toUpperCase() : (k === '⇧' && shift ? '⇪' : k);
          b.textContent = label;
          b.style.cssText = `flex:${k.length > 1 ? 1.6 : 1};border-radius:9px;border:1px solid rgba(255,255,255,.14);
            background:rgba(255,255,255,.08);color:var(--text);font-size:15px;
            ${k === '⇧' && shift ? 'background:var(--accent);color:#04202a;' : ''}`;
          b.addEventListener('click', () => press(k));
          r.appendChild(b);
        });
        kbd.appendChild(r);
      });
      // space row
      const r = document.createElement('div');
      r.style.cssText = 'display:flex;gap:5px;justify-content:center;flex:1';
      [['123', () => toastNums()], ['space', () => type(' ')], ['enter', () => type('\n')]].forEach(([label, fn]) => {
        const b = document.createElement('button');
        b.textContent = label === 'space' ? '␣' : label === 'enter' ? '↵' : label;
        b.style.cssText = `flex:${label === 'space' ? 4 : 1.6};border-radius:9px;border:1px solid rgba(255,255,255,.14);
          background:rgba(255,255,255,.08);color:var(--text);font-size:14px`;
        b.addEventListener('click', fn);
        r.appendChild(b);
      });
      kbd.appendChild(r);
    }

    function type(s) {
      const st = ta.selectionStart ?? ta.value.length, en = ta.selectionEnd ?? st;
      ta.value = ta.value.slice(0, st) + s + ta.value.slice(en);
      ta.focus(); ta.selectionStart = ta.selectionEnd = st + s.length;
    }
    function press(k) {
      if (k === '⇧') { shift = !shift; render(); return; }
      if (k === '⌫') {
        const st = ta.selectionStart ?? ta.value.length, en = ta.selectionEnd ?? st;
        if (st === en && st > 0) { ta.value = ta.value.slice(0, st - 1) + ta.value.slice(en); ta.selectionStart = ta.selectionEnd = st - 1; }
        else { ta.value = ta.value.slice(0, st) + ta.value.slice(en); ta.selectionStart = ta.selectionEnd = st; }
        return;
      }
      type(shift ? k.toUpperCase() : k);
      if (shift) { shift = false; render(); }
    }
    function toastNums() {
      // simple numbers/symbols overlay row
      const r = kbd.firstChild;
      r.innerHTML = '';
      ['1','2','3','4','5','6','7','8','9','0'].forEach((k) => {
        const b = document.createElement('button');
        b.textContent = k;
        b.style.cssText = 'flex:1;border-radius:9px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.08);color:var(--text);font-size:15px';
        b.addEventListener('click', () => type(k));
        r.appendChild(b);
      });
    }
    body.querySelector('.close-kb').addEventListener('click', () => {
      import('../spatial/windowManager.js').then(({ closeWindow }) => closeWindow(body.closest('.glass-window').dataset.win));
    });
    render();
    ta.focus();
  },
};
