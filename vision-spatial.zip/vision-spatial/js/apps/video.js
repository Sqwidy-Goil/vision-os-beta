import { toast } from '../core/errors.js';

const icon = `<svg viewBox="0 0 24 24"><rect x="3" y="5" width="14" height="14" rx="3"/><path d="M17 10l4-2v8l-4-2"/></svg>`;

export const videoApp = {
  id: 'video', name: 'Video', icon, width: 360, height: 420,
  mount(body, rec) {
    body.innerHTML = `
      <div class="app">
        <input type="file" accept="video/*" hidden>
        <button class="act pick">Choose video…</button>
        <video style="width:100%;border-radius:12px;background:#000" playsinline controlslist="nodownload"></video>
        <div class="row">
          <button class="act play">▶ Play</button>
          <input type="range" class="seek" min="0" max="1000" value="0" style="flex:2">
        </div>
        <div class="row">
          <span class="hint vol">🔊</span>
          <input type="range" class="vol" min="0" max="1" step="0.01" value="1" style="flex:2">
          <button class="act fs">⛶</button>
        </div>
        <div class="hint info">No video loaded.</div>
      </div>`;
    const file = body.querySelector('input[type=file]');
    const video = body.querySelector('video');
    const seek = body.querySelector('.seek');
    const info = body.querySelector('.info');

    body.querySelector('.pick').addEventListener('click', () => file.click());
    file.addEventListener('change', () => {
      const f = file.files[0];
      if (!f) return;
      video.src = URL.createObjectURL(f);
      info.textContent = `${f.name} — ${(f.size / 1e6).toFixed(1)} MB`;
      video.play().catch(() => {});
    });
    video.addEventListener('error', () => { if (video.src) toast('Could not play this video format.', 'error'); });
    video.addEventListener('loadedmetadata', () => {
      info.textContent += ` — ${Math.round(video.duration)}s`;
    });

    body.querySelector('.play').addEventListener('click', () => {
      if (!video.src) return toast('Choose a video first.');
      video.paused ? video.play() : video.pause();
    });
    video.addEventListener('play', () => body.querySelector('.play').textContent = '⏸ Pause');
    video.addEventListener('pause', () => body.querySelector('.play').textContent = '▶ Play');

    seek.addEventListener('input', () => {
      if (video.duration) video.currentTime = (seek.value / 1000) * video.duration;
    });
    video.addEventListener('timeupdate', () => {
      if (video.duration) seek.value = (video.currentTime / video.duration) * 1000;
    });
    body.querySelector('.vol').addEventListener('input', (e) => { video.volume = +e.target.value; });
    body.querySelector('.fs').addEventListener('click', () => {
      const w = rec.el;
      const doc = document;
      if (!doc.fullscreenElement && w.requestFullscreen) w.requestFullscreen().catch(() => video.webkitEnterFullscreen?.());
      else if (doc.exitFullscreen) doc.exitFullscreen();
    });
  },
};
