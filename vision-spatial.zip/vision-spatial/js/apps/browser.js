import { toast } from '../core/errors.js';

const icon = `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.5 3 14.5 0 18M12 3c-3 3.5-3 14.5 0 18"/></svg>`;

export const browserApp = {
  id: 'browser', name: 'Browser', icon, width: 360, height: 460,
  mount(body) {
    body.innerHTML = `
      <div class="app">
        <form class="field">
          <input type="text" inputmode="url" placeholder="Search or enter URL" aria-label="Address">
          <button class="act" type="submit">Go</button>
        </form>
        <div class="hint">Many sites block embedding (X-Frame-Options / CSP). If a page refuses to load, use “Open in Safari”.</div>
        <div class="frame-wrap" style="flex:1;position:relative;border-radius:12px;overflow:hidden;background:rgba(0,0,0,.2)">
          <iframe style="width:100%;height:100%;border:0" sandbox="allow-scripts allow-same-origin allow-forms"></iframe>
          <div class="frame-err" hidden style="position:absolute;inset:0;display:grid;place-items:center;text-align:center;padding:20px;color:var(--text-dim);font-size:13px;background:rgba(0,0,0,.35)"></div>
        </div>
        <div class="row">
          <button class="act back">◀ Back</button>
          <button class="act fwd">Forward ▶</button>
          <button class="act reload">↻</button>
          <a class="act" style="text-decoration:none;display:inline-block" target="_blank" rel="noopener">Open in Safari ↗</a>
        </div>
      </div>`;
    const form = body.querySelector('form');
    const input = body.querySelector('input');
    const iframe = body.querySelector('iframe');
    const err = body.querySelector('.frame-err');
    const safari = body.querySelector('a');

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      let v = input.value.trim();
      if (!v) return;
      if (!/^https?:\/\//i.test(v)) {
        v = v.includes('.') && !v.includes(' ') ? 'https://' + v
          : 'https://duckduckgo.com/?q=' + encodeURIComponent(v);
      }
      load(v);
    });

    function load(url) {
      err.hidden = true;
      iframe.src = url;
      safari.href = url;
      // Heuristic: same-origin iframe errors can't be read cross-origin; rely on timeout fallback message
      setTimeout(() => {
        try {
          const doc = iframe.contentDocument; // throws cross-origin
          if (!doc || (!doc.body?.innerHTML && !iframe.contentWindow?.location.href)) {
            err.textContent = 'This page cannot be displayed in an embedded frame. Use “Open in Safari”.';
            err.hidden = false;
          }
        } catch {
          err.textContent = 'This page cannot be displayed in an embedded frame (site blocks embedding). Use “Open in Safari”.';
          err.hidden = false;
        }
      }, 6000);
      toast('Loading… note: some sites block embedding.');
    }

    body.querySelector('.back').addEventListener('click', () => { try { iframe.contentWindow.history.back(); } catch { toast('History unavailable for this page.'); } });
    body.querySelector('.fwd').addEventListener('click', () => { try { iframe.contentWindow.history.forward(); } catch { toast('History unavailable for this page.'); } });
    body.querySelector('.reload').addEventListener('click', () => { if (iframe.src) iframe.src = iframe.src; });
  },
};
