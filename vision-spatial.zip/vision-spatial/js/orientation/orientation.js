// Device orientation tracking with iOS permission flow, smoothing, recentering
import { state, setState } from '../core/state.js';
import { toast } from '../core/errors.js';

let raw = { alpha: 0, beta: 0, gamma: 0 };
let smoothing = { alpha: 0, beta: 0, gamma: 0 };
let centered = { alpha: 0, beta: 0, gamma: 0 };
let raf = null;
let last = null;

const SMOOTH = 0.12; // low-pass factor

export function initOrientation(onView) {
  const handler = (e) => {
    if (e.alpha === null && e.beta === null) return;
    raw = { alpha: e.alpha || 0, beta: e.beta || 0, gamma: e.gamma || 0 };
    setState({ orientation: { ...state.orientation, supported: true } });
  };
  window.addEventListener('deviceorientation', handler);

  // Smoothing loop
  const tick = () => {
    for (const k of ['alpha', 'beta', 'gamma']) {
      let d = raw[k] - smoothing[k];
      if (k === 'alpha' && d > 180) d -= 360;
      if (k === 'alpha' && d < -180) d += 360;
      smoothing[k] += d * SMOOTH;
    }
    // Map to view offsets: yaw from alpha (relative to center), pitch from beta
    let yaw = ((smoothing.alpha - centered.alpha + 540) % 360) - 180;
    let pitch = clamp(smoothing.beta - centered.beta, -45, 45);
    let roll = clamp(smoothing.gamma - centered.gamma, -45, 45);
    // Ignore tiny drift
    if (Math.abs(yaw) < 0.15) yaw = 0;
    if (Math.abs(pitch) < 0.15) pitch = 0;
    state.view = { yaw, pitch, roll };
    if (onView) onView(state.view);
    raf = requestAnimationFrame(tick);
  };
  raf = requestAnimationFrame(tick);

  document.getElementById('btn-recenter').addEventListener('click', recenter);
}

export async function requestOrientationPermission() {
  if (!state.orientation.supported) {
    toast('Device orientation is not available on this device/browser.', 'error');
    return false;
  }
  // iOS 13+ requires explicit permission request triggered by user gesture
  if (typeof DeviceOrientationEvent !== 'undefined' &&
      typeof DeviceOrientationEvent.requestPermission === 'function') {
    try {
      const res = await DeviceOrientationEvent.requestPermission();
      if (res !== 'granted') {
        toast('Orientation permission denied. Tracking disabled.', 'error');
        setState({ orientation: { ...state.orientation, enabled: false } });
        return false;
      }
    } catch (e) {
      toast(`Orientation permission error: ${e.message}`, 'error');
      return false;
    }
  }
  setState({ orientation: { ...state.orientation, enabled: true } });
  return true;
}

export function recenter() {
  centered = { ...smoothing };
  state.orientation.calibrated = true;
  toast('View recentered');
}

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
