// Centralized error handling + user-facing toasts
export function toast(msg, type = 'info', ms = 4200) {
  const box = document.getElementById('toasts');
  const el = document.createElement('div');
  el.className = 'toast' + (type === 'error' ? ' err' : '');
  el.textContent = msg;
  box.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .4s'; setTimeout(() => el.remove(), 420); }, ms);
}

export function fatal(context, err) {
  console.error(`[VISI0N:${context}]`, err);
  toast(`${context}: ${err?.message || err}`, 'error', 6500);
}

export function unsupported(what, recovery) {
  toast(`${what} is not supported in this browser.${recovery ? ' ' + recovery : ''}`, 'error', 6000);
}

export const guard = (context) => (fn) => async (...args) => {
  try { return await fn(...args); } catch (e) { fatal(context, e); }
};
