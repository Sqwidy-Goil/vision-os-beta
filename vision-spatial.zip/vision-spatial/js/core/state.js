// Central application state + pub/sub
const listeners = new Map();
export const state = {
  env: 'dark',
  quality: 'balanced',
  windows: new Map(),        // id -> window record
  focused: null,
  camera: { active: false, error: null },
  orientation: { enabled: false, supported: 'DeviceOrientationEvent' in window, calibrated: false },
  hands: { enabled: false, loaded: false },
  view: { yaw: 0, pitch: 0, roll: 0 },
  net: navigator.onLine,
};

export function on(evt, fn) {
  if (!listeners.has(evt)) listeners.set(evt, new Set());
  listeners.get(evt).add(fn);
  return () => listeners.get(evt).delete(fn);
}
export function emit(evt, payload) {
  (listeners.get(evt) || []).forEach((fn) => { try { fn(payload); } catch (e) { console.error(e); } });
}
export function setState(patch) { Object.assign(state, patch); emit('state', patch); }
